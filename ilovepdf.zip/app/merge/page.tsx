import type { Metadata } from "next"
import { MergePDFClient } from "./client"
import {
  JsonLd,
  createWebApplicationSchema,
  createHowToSchema,
  createBreadcrumbSchema,
  createFAQSchema,
} from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Merge PDF - Combine PDF Files Online Free | PDFTools",
  description:
    "Merge multiple PDF files into one document online for free. Combine PDFs in any order, fast and secure. No registration required. Works on all devices.",
  keywords: [
    "merge pdf",
    "combine pdf",
    "join pdf",
    "pdf merger",
    "merge pdf files",
    "combine pdf online",
    "free pdf merger",
    "pdf combiner",
  ],
  openGraph: {
    title: "Merge PDF - Combine PDF Files Online Free",
    description:
      "Merge multiple PDF files into one document online for free. Fast, secure, and easy to use.",
    url: "https://pdftools.com/merge",
    siteName: "PDFTools",
    type: "website",
    images: [
      {
        url: "https://pdftools.com/og/merge-pdf.png",
        width: 1200,
        height: 630,
        alt: "Merge PDF Online",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Merge PDF - Combine PDF Files Online Free",
    description:
      "Merge multiple PDF files into one document online for free. Fast, secure, and easy to use.",
  },
  alternates: {
    canonical: "https://pdftools.com/merge",
    languages: {
      "en-US": "https://pdftools.com/merge",
      "ar-SA": "https://pdftools.com/ar/merge",
      "es-ES": "https://pdftools.com/es/merge",
    },
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
}

const instructions = [
  "Select or drag and drop multiple PDF files above.",
  "Rearrange the order of files if needed by dragging them.",
  "Click 'Merge PDFs' to combine them into one file.",
  "Download your merged PDF instantly.",
]

const faqs = [
  {
    question: "Is it free to merge PDF files?",
    answer:
      "Yes, our PDF merger is completely free to use. No registration or payment required.",
  },
  {
    question: "Is my data secure when merging PDFs?",
    answer:
      "Absolutely. All files are processed securely and automatically deleted after processing. We never store or share your files.",
  },
  {
    question: "How many PDF files can I merge at once?",
    answer:
      "You can merge unlimited PDF files at once. There is no limit on the number of files.",
  },
  {
    question: "Will the quality of my PDFs be affected?",
    answer:
      "No, merging PDFs does not affect the quality. All content, formatting, and images remain exactly as they were.",
  },
]

export default function MergePDFPage() {
  return (
    <>
      <JsonLd
        data={createWebApplicationSchema(
          "Merge PDF - PDFTools",
          "Merge multiple PDF files into one document online for free",
          "https://pdftools.com/merge",
          "UtilitiesApplication"
        )}
      />
      <JsonLd
        data={createHowToSchema(
          "How to Merge PDF Files Online",
          "Learn how to combine multiple PDF files into one document",
          instructions
        )}
      />
      <JsonLd
        data={createBreadcrumbSchema([
          { name: "Home", url: "https://pdftools.com" },
          { name: "Merge PDF", url: "https://pdftools.com/merge" },
        ])}
      />
      <JsonLd data={createFAQSchema(faqs)} />
      <MergePDFClient />
    </>
  )
}
