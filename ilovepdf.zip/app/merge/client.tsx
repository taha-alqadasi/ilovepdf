"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Merge } from "lucide-react"

export function MergePDFClient() {
  return (
    <PDFToolPage
      title="Merge PDF"
      description="Combine multiple PDF files into one document. Fast, free, and secure."
      icon={<Merge className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#e5322d]"
      buttonText="Merge PDFs"
      acceptMultiple={true}
      acceptTypes=".pdf"
      instructions={[
        "Select or drag and drop multiple PDF files above.",
        "Rearrange the order of files if needed by dragging them.",
        "Click 'Merge PDFs' to combine them into one file.",
        "Download your merged PDF instantly.",
      ]}
    />
  )
}
