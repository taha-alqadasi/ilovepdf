"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Table } from "lucide-react"

export function ExcelToPDFClient() {
  return (
    <PDFToolPage
      title="Excel to PDF"
      description="Make EXCEL spreadsheets easy to read by converting them to PDF."
      icon={<Table className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#16a34a]"
      buttonText="Convert to PDF"
      acceptMultiple={true}
      acceptTypes=".xls,.xlsx"
      instructions={[
        "Upload your Excel file (XLS or XLSX).",
        "Wait for the conversion to complete.",
        "Download your PDF file.",
      ]}
    />
  )
}
