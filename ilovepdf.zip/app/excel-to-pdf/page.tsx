import type { Metadata } from "next"
import { ExcelToPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Excel to PDF - Convert XLSX to PDF Online Free | PDFTools",
  description: "Convert Excel spreadsheets to PDF online for free. Transform XLS and XLSX files into PDF format. No registration required.",
  keywords: ["excel to pdf", "convert excel to pdf", "xlsx to pdf", "xls to pdf", "spreadsheet to pdf", "excel to pdf online"],
  openGraph: { title: "Excel to PDF - Convert XLSX to PDF Online Free", description: "Convert Excel spreadsheets to PDF online for free.", url: "https://pdftools.com/excel-to-pdf", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/excel-to-pdf" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your Excel file (XLS or XLSX).", "Wait for the conversion.", "Download your PDF."]
const faqs = [{ question: "Are formulas preserved?", answer: "The PDF will show the calculated values, preserving the visual layout of your spreadsheet." }]

export default function ExcelToPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Excel to PDF - PDFTools", "Convert Excel files to PDF", "https://pdftools.com/excel-to-pdf", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Convert Excel to PDF", "Convert spreadsheets to PDF", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Excel to PDF", url: "https://pdftools.com/excel-to-pdf" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <ExcelToPDFClient />
    </>
  )
}
