"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Minimize2 } from "lucide-react"

export function CompressPDFClient() {
  return (
    <PDFToolPage
      title="Compress PDF"
      description="Reduce file size while optimizing for maximal PDF quality."
      icon={<Minimize2 className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#16a34a]"
      buttonText="Compress PDF"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload the PDF file you want to compress.",
        "Choose compression level: low, medium, or high.",
        "Click 'Compress PDF' to reduce file size.",
        "Download your compressed PDF.",
      ]}
    />
  )
}
