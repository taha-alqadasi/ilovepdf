import type { Metadata } from "next"
import { CompressPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Compress PDF - Reduce PDF File Size Online Free | PDFTools",
  description: "Compress PDF files online for free. Reduce PDF file size while maintaining quality. Fast, secure, and easy to use PDF compressor.",
  keywords: ["compress pdf", "reduce pdf size", "pdf compressor", "shrink pdf", "compress pdf online", "free pdf compressor", "minimize pdf"],
  openGraph: {
    title: "Compress PDF - Reduce PDF File Size Online Free",
    description: "Compress PDF files online for free. Reduce file size while maintaining quality.",
    url: "https://pdftools.com/compress",
    siteName: "PDFTools",
    type: "website",
  },
  twitter: { card: "summary_large_image", title: "Compress PDF - Reduce PDF File Size Online Free", description: "Compress PDF files online for free. Reduce file size while maintaining quality." },
  alternates: { canonical: "https://pdftools.com/compress" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload the PDF file you want to compress.", "Choose compression level: low, medium, or high.", "Click 'Compress PDF' to reduce file size.", "Download your compressed PDF."]
const faqs = [
  { question: "How much can I reduce my PDF size?", answer: "Depending on the content, you can reduce PDF size by up to 90% without significant quality loss." },
  { question: "Will compression affect PDF quality?", answer: "Our smart compression algorithm maintains the best balance between file size and quality." },
]

export default function CompressPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Compress PDF - PDFTools", "Compress PDF files and reduce file size online", "https://pdftools.com/compress", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Compress PDF Files", "Learn how to reduce PDF file size", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Compress PDF", url: "https://pdftools.com/compress" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <CompressPDFClient />
    </>
  )
}
