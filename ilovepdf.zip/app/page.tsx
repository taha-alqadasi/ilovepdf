import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { ToolsGrid } from "@/components/tools-grid"
import { WorkYourWaySection } from "@/components/work-your-way-section"
import { PremiumSection } from "@/components/premium-section"
import { TrustSection } from "@/components/trust-section"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-white">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <ToolsGrid />
        <WorkYourWaySection />
        <PremiumSection />
        <TrustSection />
      </main>
      <Footer />
    </div>
  )
}
