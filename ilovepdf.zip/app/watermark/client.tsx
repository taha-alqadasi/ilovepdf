"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Stamp } from "lucide-react"

export function WatermarkClient() {
  return (
    <PDFToolPage
      title="Watermark"
      description="Stamp an image or text over your PDF in seconds. Choose the typography, transparency and position."
      icon={<Stamp className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#a855f7]"
      buttonText="Add Watermark"
      acceptMultiple={true}
      acceptTypes=".pdf"
      instructions={[
        "Upload the PDF files you want to watermark.",
        "Choose text or image watermark.",
        "Customize position, size, and transparency.",
        "Download your watermarked PDF.",
      ]}
    />
  )
}
