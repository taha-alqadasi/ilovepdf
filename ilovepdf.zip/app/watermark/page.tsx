import type { Metadata } from "next"
import { WatermarkClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Add Watermark to PDF - Watermark PDF Online Free | PDFTools",
  description: "Add watermark to PDF files online for free. Stamp text or images on your PDF documents. Customize position, transparency, and font. No registration required.",
  keywords: ["watermark pdf", "add watermark to pdf", "pdf watermark", "stamp pdf", "pdf stamp", "watermark pdf online", "text watermark pdf"],
  openGraph: { title: "Add Watermark to PDF Online Free", description: "Add watermark to PDF files online for free.", url: "https://pdftools.com/watermark", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/watermark" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file.", "Add text or image watermark.", "Customize position and transparency.", "Download your watermarked PDF."]
const faqs = [{ question: "Can I use my own logo?", answer: "Yes, you can upload your own image to use as a watermark." }]

export default function WatermarkPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Watermark PDF - PDFTools", "Add watermarks to PDF files", "https://pdftools.com/watermark", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Add Watermark to PDF", "Add text or image watermarks to PDF", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Watermark PDF", url: "https://pdftools.com/watermark" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <WatermarkClient />
    </>
  )
}
