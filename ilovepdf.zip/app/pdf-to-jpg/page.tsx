import type { Metadata } from "next"
import { PDFToJPGClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "PDF to JPG - Convert PDF to Images Online Free | PDFTools",
  description: "Convert PDF pages to JPG images online for free. Extract all images from PDF or convert each page to a high-quality JPG. No registration required.",
  keywords: ["pdf to jpg", "convert pdf to jpg", "pdf to image", "pdf to jpeg", "extract images from pdf", "pdf to jpg online", "pdf to picture"],
  openGraph: { title: "PDF to JPG - Convert PDF to Images Online Free", description: "Convert PDF pages to JPG images online for free.", url: "https://pdftools.com/pdf-to-jpg", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/pdf-to-jpg" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file.", "Choose to convert pages or extract images.", "Download your JPG images."]
const faqs = [{ question: "What image quality can I expect?", answer: "You can choose from different quality levels, up to 300 DPI for high-resolution images." }]

export default function PDFToJPGPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("PDF to JPG - PDFTools", "Convert PDF pages to JPG images", "https://pdftools.com/pdf-to-jpg", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Convert PDF to JPG", "Convert PDF pages to images", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "PDF to JPG", url: "https://pdftools.com/pdf-to-jpg" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <PDFToJPGClient />
    </>
  )
}
