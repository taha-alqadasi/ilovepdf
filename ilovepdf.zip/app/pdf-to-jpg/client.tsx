"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { ImageIcon } from "lucide-react"

export function PDFToJPGClient() {
  return (
    <PDFToolPage
      title="PDF to JPG"
      description="Convert each PDF page into a JPG or extract all images contained in a PDF."
      icon={<ImageIcon className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#eab308]"
      buttonText="Convert to JPG"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload your PDF file.",
        "Choose to convert pages or extract images.",
        "Download your JPG images as a ZIP file.",
      ]}
    />
  )
}
