"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { LayoutGrid } from "lucide-react"

export function OrganizePDFClient() {
  return (
    <PDFToolPage
      title="Organize PDF"
      description="Sort pages of your PDF file however you like. Delete PDF pages or add PDF pages to your document at your convenience."
      icon={<LayoutGrid className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#e5322d]"
      buttonText="Organize PDF"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload your PDF file.",
        "Drag and drop pages to reorder them.",
        "Delete unwanted pages or add new ones.",
        "Download your organized PDF.",
      ]}
    />
  )
}
