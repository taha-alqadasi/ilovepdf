import type { Metadata } from "next"
import { OrganizePDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Organize PDF - Rearrange PDF Pages Online Free | PDFTools",
  description: "Organize and rearrange PDF pages online for free. Delete, reorder, rotate, and add pages to your PDF. No registration required.",
  keywords: ["organize pdf", "rearrange pdf pages", "reorder pdf", "delete pdf pages", "pdf organizer", "organize pdf online"],
  openGraph: { title: "Organize PDF - Rearrange PDF Pages Online Free", description: "Organize and rearrange PDF pages online for free.", url: "https://pdftools.com/organize", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/organize" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file.", "Drag and drop pages to reorder.", "Delete or rotate individual pages.", "Download your organized PDF."]
const faqs = [{ question: "Can I delete specific pages?", answer: "Yes, you can delete, reorder, or rotate any page in your PDF." }]

export default function OrganizePDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Organize PDF - PDFTools", "Rearrange and organize PDF pages", "https://pdftools.com/organize", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Organize PDF Pages", "Rearrange and delete PDF pages", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Organize PDF", url: "https://pdftools.com/organize" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <OrganizePDFClient />
    </>
  )
}
