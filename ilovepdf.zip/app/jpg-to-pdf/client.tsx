"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { ImageIcon } from "lucide-react"

export function JPGToPDFClient() {
  return (
    <PDFToolPage
      title="JPG to PDF"
      description="Convert JPG images to PDF in seconds. Easily adjust orientation and margins."
      icon={<ImageIcon className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#eab308]"
      buttonText="Convert to PDF"
      acceptMultiple={true}
      acceptTypes=".jpg,.jpeg,.png,.gif,.webp"
      instructions={[
        "Upload your images (JPG, PNG, GIF, WEBP).",
        "Arrange the order and adjust settings.",
        "Download your PDF document.",
      ]}
    />
  )
}
