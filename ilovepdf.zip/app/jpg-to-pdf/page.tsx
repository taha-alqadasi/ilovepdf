import type { Metadata } from "next"
import { JPGToPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "JPG to PDF - Convert Images to PDF Online Free | PDFTools",
  description: "Convert JPG images to PDF online for free. Combine multiple images into one PDF document. Adjust orientation and margins. No registration required.",
  keywords: ["jpg to pdf", "convert jpg to pdf", "image to pdf", "jpeg to pdf", "photo to pdf", "jpg to pdf online", "picture to pdf"],
  openGraph: { title: "JPG to PDF - Convert Images to PDF Online Free", description: "Convert JPG images to PDF online for free.", url: "https://pdftools.com/jpg-to-pdf", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/jpg-to-pdf" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your JPG images.", "Arrange the order and set options.", "Download your PDF."]
const faqs = [{ question: "Can I combine multiple images?", answer: "Yes, you can combine multiple JPG images into a single PDF document." }]

export default function JPGToPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("JPG to PDF - PDFTools", "Convert JPG images to PDF", "https://pdftools.com/jpg-to-pdf", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Convert JPG to PDF", "Convert images to PDF", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "JPG to PDF", url: "https://pdftools.com/jpg-to-pdf" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <JPGToPDFClient />
    </>
  )
}
