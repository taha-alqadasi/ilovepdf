"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Wrench } from "lucide-react"

export function RepairPDFClient() {
  return (
    <PDFToolPage
      title="Repair PDF"
      description="Repair a damaged PDF and recover data from corrupt PDF. Fix PDF files with our Repair tool."
      icon={<Wrench className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#ef4444]"
      buttonText="Repair PDF"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload your corrupted or damaged PDF.",
        "Our tool will analyze and repair the file.",
        "Wait for the repair process to complete.",
        "Download your repaired PDF.",
      ]}
    />
  )
}
