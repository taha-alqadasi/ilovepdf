import type { Metadata } from "next"
import { RepairPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Repair PDF - Fix Corrupted PDF Files Online Free | PDFTools",
  description: "Repair damaged and corrupted PDF files online for free. Recover data from broken PDFs. Fix PDF files that won't open. No registration required.",
  keywords: ["repair pdf", "fix pdf", "corrupted pdf", "damaged pdf", "recover pdf", "pdf repair online", "broken pdf"],
  openGraph: { title: "Repair PDF - Fix Corrupted PDF Files Online Free", description: "Repair damaged and corrupted PDF files online for free.", url: "https://pdftools.com/repair", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/repair" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your corrupted PDF file.", "Wait for the repair process.", "Download your repaired PDF."]
const faqs = [{ question: "Can all PDFs be repaired?", answer: "We can repair most corrupted PDFs, but severely damaged files may not be fully recoverable." }]

export default function RepairPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Repair PDF - PDFTools", "Fix corrupted and damaged PDF files", "https://pdftools.com/repair", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Repair Corrupted PDF", "Fix damaged PDF files", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Repair PDF", url: "https://pdftools.com/repair" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <RepairPDFClient />
    </>
  )
}
