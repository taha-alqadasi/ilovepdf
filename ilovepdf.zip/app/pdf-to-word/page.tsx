import type { Metadata } from "next"
import { PDFToWordClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "PDF to Word - Convert PDF to DOCX Online Free | PDFTools",
  description: "Convert PDF to Word documents online for free. Transform PDF files into editable DOC and DOCX format with high accuracy. No registration required.",
  keywords: ["pdf to word", "convert pdf to word", "pdf to docx", "pdf to doc", "pdf converter", "pdf to word online", "free pdf to word"],
  openGraph: {
    title: "PDF to Word - Convert PDF to DOCX Online Free",
    description: "Convert PDF to Word documents online for free. High accuracy conversion.",
    url: "https://pdftools.com/pdf-to-word",
    siteName: "PDFTools",
    type: "website",
  },
  twitter: { card: "summary_large_image", title: "PDF to Word - Convert PDF to DOCX Online Free", description: "Convert PDF to Word documents online for free." },
  alternates: { canonical: "https://pdftools.com/pdf-to-word" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file.", "Wait for the conversion to complete.", "Download your Word document."]
const faqs = [
  { question: "Is the conversion accurate?", answer: "Yes, our converter maintains high accuracy for text, images, and formatting." },
  { question: "What Word format do I get?", answer: "You can download in both DOC and DOCX formats." },
]

export default function PDFToWordPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("PDF to Word - PDFTools", "Convert PDF files to editable Word documents", "https://pdftools.com/pdf-to-word", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Convert PDF to Word", "Learn how to convert PDF to Word documents", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "PDF to Word", url: "https://pdftools.com/pdf-to-word" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <PDFToWordClient />
    </>
  )
}
