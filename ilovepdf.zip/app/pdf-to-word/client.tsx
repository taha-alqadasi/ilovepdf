"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { FileText } from "lucide-react"

export function PDFToWordClient() {
  return (
    <PDFToolPage
      title="PDF to Word"
      description="Easily convert your PDF files into easy to edit DOC and DOCX documents."
      icon={<FileText className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#2563eb]"
      buttonText="Convert to Word"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload the PDF file you want to convert.",
        "Wait for the conversion to complete.",
        "Download your editable Word document.",
      ]}
    />
  )
}
