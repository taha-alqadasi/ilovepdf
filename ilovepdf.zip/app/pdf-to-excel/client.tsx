"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Table } from "lucide-react"

export function PDFToExcelClient() {
  return (
    <PDFToolPage
      title="PDF to Excel"
      description="Pull data straight from PDFs into Excel spreadsheets in a few short seconds."
      icon={<Table className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#16a34a]"
      buttonText="Convert to Excel"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload the PDF file containing tables.",
        "Our tool will automatically detect tables.",
        "Download your Excel spreadsheet.",
      ]}
    />
  )
}
