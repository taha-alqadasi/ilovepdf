import type { Metadata } from "next"
import { PDFToExcelClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "PDF to Excel - Convert PDF to XLSX Online Free | PDFTools",
  description: "Convert PDF to Excel spreadsheets online for free. Extract tables and data from PDF files into editable XLSX format. No registration required.",
  keywords: ["pdf to excel", "convert pdf to excel", "pdf to xlsx", "pdf to spreadsheet", "extract table from pdf", "pdf to excel online", "free pdf to excel"],
  openGraph: { title: "PDF to Excel - Convert PDF to XLSX Online Free", description: "Convert PDF to Excel spreadsheets online for free.", url: "https://pdftools.com/pdf-to-excel", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/pdf-to-excel" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file with tables.", "Our tool will detect and extract tables.", "Download your Excel spreadsheet."]
const faqs = [{ question: "Can it extract tables accurately?", answer: "Yes, our AI-powered tool accurately detects and extracts tables from PDFs." }]

export default function PDFToExcelPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("PDF to Excel - PDFTools", "Convert PDF files to Excel spreadsheets", "https://pdftools.com/pdf-to-excel", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Convert PDF to Excel", "Extract tables from PDF to Excel", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "PDF to Excel", url: "https://pdftools.com/pdf-to-excel" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <PDFToExcelClient />
    </>
  )
}
