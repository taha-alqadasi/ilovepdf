import type { Metadata } from "next"
import { PPTToPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "PowerPoint to PDF - Convert PPTX to PDF Online Free | PDFTools",
  description: "Convert PowerPoint presentations to PDF online for free. Transform PPT and PPTX files into PDF format. No registration required.",
  keywords: ["powerpoint to pdf", "convert ppt to pdf", "pptx to pdf", "presentation to pdf", "slides to pdf", "powerpoint to pdf online"],
  openGraph: { title: "PowerPoint to PDF - Convert PPTX to PDF Online Free", description: "Convert PowerPoint presentations to PDF online for free.", url: "https://pdftools.com/powerpoint-to-pdf", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/powerpoint-to-pdf" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PowerPoint file.", "Wait for the conversion.", "Download your PDF."]
const faqs = [{ question: "Are animations preserved?", answer: "PDF is a static format, so animations are not preserved, but all visual elements are included." }]

export default function PPTToPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("PowerPoint to PDF - PDFTools", "Convert PowerPoint to PDF", "https://pdftools.com/powerpoint-to-pdf", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Convert PowerPoint to PDF", "Convert presentations to PDF", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "PowerPoint to PDF", url: "https://pdftools.com/powerpoint-to-pdf" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <PPTToPDFClient />
    </>
  )
}
