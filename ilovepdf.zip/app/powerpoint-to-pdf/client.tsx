"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Presentation } from "lucide-react"

export function PPTToPDFClient() {
  return (
    <PDFToolPage
      title="PowerPoint to PDF"
      description="Make PPT and PPTX slideshows easy to view by converting them to PDF."
      icon={<Presentation className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#ea580c]"
      buttonText="Convert to PDF"
      acceptMultiple={true}
      acceptTypes=".ppt,.pptx"
      instructions={[
        "Upload your PowerPoint file (PPT or PPTX).",
        "Wait for the conversion to complete.",
        "Download your PDF file.",
      ]}
    />
  )
}
