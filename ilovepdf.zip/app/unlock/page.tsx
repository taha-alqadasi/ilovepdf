import type { Metadata } from "next"
import { UnlockPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Unlock PDF - Remove Password from PDF Online Free | PDFTools",
  description: "Remove password from PDF files online for free. Unlock password-protected PDF documents to use them freely. No registration required.",
  keywords: ["unlock pdf", "remove pdf password", "decrypt pdf", "pdf unlocker", "remove password from pdf", "unlock pdf online"],
  openGraph: { title: "Unlock PDF - Remove Password from PDF Online Free", description: "Remove password from PDF files online for free.", url: "https://pdftools.com/unlock", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/unlock" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your password-protected PDF.", "Enter the password.", "Download your unlocked PDF."]
const faqs = [{ question: "Do I need to know the password?", answer: "Yes, you need to provide the correct password to unlock the PDF." }]

export default function UnlockPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Unlock PDF - PDFTools", "Remove password protection from PDF files", "https://pdftools.com/unlock", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Unlock PDF", "Remove password from PDF files", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Unlock PDF", url: "https://pdftools.com/unlock" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <UnlockPDFClient />
    </>
  )
}
