"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Unlock } from "lucide-react"

export function UnlockPDFClient() {
  return (
    <PDFToolPage
      title="Unlock PDF"
      description="Remove PDF password security, giving you the freedom to use your PDFs as you want."
      icon={<Unlock className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#16a34a]"
      buttonText="Unlock PDF"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload your password-protected PDF.",
        "Enter the PDF password.",
        "Click 'Unlock PDF' to remove protection.",
        "Download your unlocked PDF.",
      ]}
    />
  )
}
