import { MetadataRoute } from "next"

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = "https://pdftools.com"
  const lastModified = new Date()

  const tools = [
    "merge",
    "split",
    "compress",
    "pdf-to-word",
    "word-to-pdf",
    "pdf-to-excel",
    "excel-to-pdf",
    "pdf-to-powerpoint",
    "powerpoint-to-pdf",
    "pdf-to-jpg",
    "jpg-to-pdf",
    "rotate",
    "protect",
    "unlock",
    "watermark",
    "sign",
    "edit",
    "organize",
    "html-to-pdf",
    "ocr",
    "page-numbers",
    "repair",
  ]

  const staticPages = [
    {
      url: baseUrl,
      lastModified,
      changeFrequency: "daily" as const,
      priority: 1,
    },
    {
      url: `${baseUrl}/pricing`,
      lastModified,
      changeFrequency: "weekly" as const,
      priority: 0.8,
    },
    {
      url: `${baseUrl}/about`,
      lastModified,
      changeFrequency: "monthly" as const,
      priority: 0.5,
    },
    {
      url: `${baseUrl}/contact`,
      lastModified,
      changeFrequency: "monthly" as const,
      priority: 0.5,
    },
    {
      url: `${baseUrl}/privacy`,
      lastModified,
      changeFrequency: "yearly" as const,
      priority: 0.3,
    },
    {
      url: `${baseUrl}/terms`,
      lastModified,
      changeFrequency: "yearly" as const,
      priority: 0.3,
    },
  ]

  const toolPages = tools.map((tool) => ({
    url: `${baseUrl}/${tool}`,
    lastModified,
    changeFrequency: "weekly" as const,
    priority: 0.9,
  }))

  return [...staticPages, ...toolPages]
}
