import type { Metadata } from "next"
import { PageNumbersClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Add Page Numbers to PDF Online Free | PDFTools",
  description: "Add page numbers to PDF documents online for free. Customize position, format, and typography. No registration required.",
  keywords: ["add page numbers to pdf", "pdf page numbers", "number pdf pages", "page numbering", "pdf page numbering online"],
  openGraph: { title: "Add Page Numbers to PDF Online Free", description: "Add page numbers to PDF documents online for free.", url: "https://pdftools.com/page-numbers", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/page-numbers" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file.", "Choose position and format.", "Customize typography.", "Download your numbered PDF."]
const faqs = [{ question: "Can I choose where numbers appear?", answer: "Yes, you can position numbers at the top or bottom, left, center, or right." }]

export default function PageNumbersPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Page Numbers - PDFTools", "Add page numbers to PDF documents", "https://pdftools.com/page-numbers", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Add Page Numbers to PDF", "Number your PDF pages", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Page Numbers", url: "https://pdftools.com/page-numbers" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <PageNumbersClient />
    </>
  )
}
