"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Hash } from "lucide-react"

export function PageNumbersClient() {
  return (
    <PDFToolPage
      title="Page Numbers"
      description="Add page numbers into PDFs with ease. Choose your positions, dimensions, typography."
      icon={<Hash className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#16a34a]"
      buttonText="Add Page Numbers"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload your PDF file.",
        "Choose the position for page numbers.",
        "Select format (1, 2, 3 or i, ii, iii).",
        "Download your numbered PDF.",
      ]}
    />
  )
}
