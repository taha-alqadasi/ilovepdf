"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { ScanText } from "lucide-react"

export function OCRClient() {
  return (
    <PDFToolPage
      title="OCR PDF"
      description="Easily convert scanned PDF into searchable and selectable documents."
      icon={<ScanText className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#0ea5e9]"
      buttonText="Apply OCR"
      acceptMultiple={false}
      acceptTypes=".pdf,.jpg,.jpeg,.png"
      instructions={[
        "Upload your scanned PDF or image.",
        "Select the language of your document.",
        "Wait for the OCR processing to complete.",
        "Download your searchable PDF.",
      ]}
    />
  )
}
