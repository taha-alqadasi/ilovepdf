import type { Metadata } from "next"
import { OCRClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "OCR PDF - Convert Scanned PDF to Searchable Text | PDFTools",
  description: "Convert scanned PDF to searchable and selectable text using OCR technology. Extract text from images and scanned documents. Free online OCR.",
  keywords: ["ocr pdf", "scanned pdf to text", "pdf ocr", "extract text from pdf", "searchable pdf", "ocr online", "image to text"],
  openGraph: { title: "OCR PDF - Convert Scanned PDF to Searchable Text", description: "Convert scanned PDF to searchable text using OCR.", url: "https://pdftools.com/ocr", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/ocr" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your scanned PDF or image.", "Select the document language.", "Wait for OCR processing.", "Download your searchable PDF."]
const faqs = [{ question: "Which languages are supported?", answer: "We support over 100 languages including English, Arabic, Chinese, Spanish, and more." }]

export default function OCRPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("OCR PDF - PDFTools", "Convert scanned documents to searchable PDF", "https://pdftools.com/ocr", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to OCR PDF Documents", "Make scanned PDFs searchable", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "OCR PDF", url: "https://pdftools.com/ocr" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <OCRClient />
    </>
  )
}
