"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { PenTool } from "lucide-react"

export function SignPDFClient() {
  return (
    <PDFToolPage
      title="Sign PDF"
      description="Sign yourself or request electronic signatures from others."
      icon={<PenTool className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#8b5cf6]"
      buttonText="Sign Document"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload the PDF document to sign.",
        "Draw, type, or upload your signature.",
        "Place your signature on the document.",
        "Download your signed PDF.",
      ]}
    />
  )
}
