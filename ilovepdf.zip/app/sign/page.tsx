import type { Metadata } from "next"
import { SignPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Sign PDF - Add Signature to PDF Online Free | PDFTools",
  description: "Sign PDF documents online for free. Add your signature or request electronic signatures from others. Legally binding e-signatures. No registration required.",
  keywords: ["sign pdf", "pdf signature", "e-signature", "electronic signature", "digital signature", "sign pdf online", "add signature to pdf"],
  openGraph: { title: "Sign PDF - Add Signature to PDF Online Free", description: "Sign PDF documents online for free.", url: "https://pdftools.com/sign", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/sign" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF document.", "Draw, type, or upload your signature.", "Place signature on the document.", "Download your signed PDF."]
const faqs = [{ question: "Is the e-signature legally binding?", answer: "Yes, electronic signatures are legally binding in most countries when proper authentication is used." }]

export default function SignPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Sign PDF - PDFTools", "Add electronic signatures to PDF documents", "https://pdftools.com/sign", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Sign PDF Documents", "Add signature to PDF files", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Sign PDF", url: "https://pdftools.com/sign" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <SignPDFClient />
    </>
  )
}
