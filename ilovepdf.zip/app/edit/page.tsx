import type { Metadata } from "next"
import { EditPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Edit PDF - Edit PDF Files Online Free | PDFTools",
  description: "Edit PDF files online for free. Add text, images, shapes, and annotations to your PDF documents. Draw, highlight, and annotate. No registration required.",
  keywords: ["edit pdf", "pdf editor", "modify pdf", "add text to pdf", "annotate pdf", "edit pdf online", "free pdf editor"],
  openGraph: { title: "Edit PDF - Edit PDF Files Online Free", description: "Edit PDF files online for free. Add text, images, and annotations.", url: "https://pdftools.com/edit", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/edit" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file.", "Add text, images, shapes, or annotations.", "Save your changes.", "Download your edited PDF."]
const faqs = [{ question: "Can I add images to PDF?", answer: "Yes, you can add images, text, shapes, and freehand drawings to your PDF." }]

export default function EditPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Edit PDF - PDFTools", "Edit and annotate PDF files online", "https://pdftools.com/edit", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Edit PDF Files", "Add text and images to PDF", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Edit PDF", url: "https://pdftools.com/edit" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <EditPDFClient />
    </>
  )
}
