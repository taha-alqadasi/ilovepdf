"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Edit3 } from "lucide-react"

export function EditPDFClient() {
  return (
    <PDFToolPage
      title="Edit PDF"
      description="Add text, images, shapes or freehand annotations to a PDF document. Edit the size, font, and color of the added content."
      icon={<Edit3 className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#f59e0b]"
      buttonText="Edit PDF"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload your PDF file.",
        "Use the editor to add text, images, or shapes.",
        "Customize fonts, colors, and sizes.",
        "Download your edited PDF.",
      ]}
    />
  )
}
