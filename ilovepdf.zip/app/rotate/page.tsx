import type { Metadata } from "next"
import { RotatePDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Rotate PDF - Rotate PDF Pages Online Free | PDFTools",
  description: "Rotate PDF pages online for free. Turn PDF pages 90, 180, or 270 degrees. Rotate all pages or specific pages. No registration required.",
  keywords: ["rotate pdf", "turn pdf", "flip pdf", "rotate pdf pages", "pdf rotation", "rotate pdf online", "rotate pdf 90 degrees"],
  openGraph: { title: "Rotate PDF - Rotate PDF Pages Online Free", description: "Rotate PDF pages online for free.", url: "https://pdftools.com/rotate", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/rotate" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file.", "Select pages and rotation angle.", "Download your rotated PDF."]
const faqs = [{ question: "Can I rotate specific pages?", answer: "Yes, you can rotate individual pages or all pages at once." }]

export default function RotatePDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Rotate PDF - PDFTools", "Rotate PDF pages online", "https://pdftools.com/rotate", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Rotate PDF Pages", "Rotate PDF pages to correct orientation", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Rotate PDF", url: "https://pdftools.com/rotate" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <RotatePDFClient />
    </>
  )
}
