"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { RotateCw } from "lucide-react"

export function RotatePDFClient() {
  return (
    <PDFToolPage
      title="Rotate PDF"
      description="Rotate your PDFs the way you need them. You can even rotate multiple PDFs at once!"
      icon={<RotateCw className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#06b6d4]"
      buttonText="Rotate PDF"
      acceptMultiple={true}
      acceptTypes=".pdf"
      instructions={[
        "Upload the PDF files you want to rotate.",
        "Select the rotation angle (90, 180, or 270 degrees).",
        "Click 'Rotate PDF' to apply changes.",
        "Download your rotated PDF.",
      ]}
    />
  )
}
