import type { Metadata } from "next"
import { SplitPDFClient } from "./client"
import {
  JsonLd,
  createWebApplicationSchema,
  createHowToSchema,
  createBreadcrumbSchema,
  createFAQSchema,
} from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Split PDF - Extract Pages from PDF Online Free | PDFTools",
  description:
    "Split PDF files into separate pages or extract specific pages online for free. Easy to use PDF splitter. No registration required.",
  keywords: [
    "split pdf",
    "pdf splitter",
    "extract pdf pages",
    "separate pdf pages",
    "split pdf online",
    "free pdf splitter",
    "divide pdf",
  ],
  openGraph: {
    title: "Split PDF - Extract Pages from PDF Online Free",
    description:
      "Split PDF files into separate pages or extract specific pages online for free. Easy and secure.",
    url: "https://pdftools.com/split",
    siteName: "PDFTools",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Split PDF - Extract Pages from PDF Online Free",
    description:
      "Split PDF files into separate pages or extract specific pages online for free.",
  },
  alternates: {
    canonical: "https://pdftools.com/split",
  },
  robots: {
    index: true,
    follow: true,
  },
}

const instructions = [
  "Upload the PDF file you want to split.",
  "Choose how you want to split: by pages, ranges, or extract all.",
  "Click 'Split PDF' to process your file.",
  "Download your split PDF files.",
]

const faqs = [
  {
    question: "Can I extract specific pages from a PDF?",
    answer: "Yes, you can select specific pages or page ranges to extract from your PDF.",
  },
  {
    question: "Is the PDF splitter free?",
    answer: "Yes, our PDF splitter is completely free with no limitations.",
  },
]

export default function SplitPDFPage() {
  return (
    <>
      <JsonLd
        data={createWebApplicationSchema(
          "Split PDF - PDFTools",
          "Split PDF files into separate pages or extract specific pages",
          "https://pdftools.com/split",
          "UtilitiesApplication"
        )}
      />
      <JsonLd data={createHowToSchema("How to Split PDF Files", "Learn how to split PDF files into separate pages", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Split PDF", url: "https://pdftools.com/split" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <SplitPDFClient />
    </>
  )
}
