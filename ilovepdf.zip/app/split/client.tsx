"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Scissors } from "lucide-react"

export function SplitPDFClient() {
  return (
    <PDFToolPage
      title="Split PDF"
      description="Separate one page or a whole set for easy conversion into independent PDF files."
      icon={<Scissors className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#e5322d]"
      buttonText="Split PDF"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload the PDF file you want to split.",
        "Choose how you want to split: by pages, ranges, or extract all.",
        "Click 'Split PDF' to process your file.",
        "Download your split PDF files.",
      ]}
    />
  )
}
