import type { Metadata } from "next"
import { WordToPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Word to PDF - Convert DOCX to PDF Online Free | PDFTools",
  description: "Convert Word documents to PDF online for free. Transform DOC and DOCX files into PDF format instantly. No registration required.",
  keywords: ["word to pdf", "convert word to pdf", "docx to pdf", "doc to pdf", "word converter", "word to pdf online", "free word to pdf"],
  openGraph: {
    title: "Word to PDF - Convert DOCX to PDF Online Free",
    description: "Convert Word documents to PDF online for free. Fast and easy conversion.",
    url: "https://pdftools.com/word-to-pdf",
    siteName: "PDFTools",
    type: "website",
  },
  alternates: { canonical: "https://pdftools.com/word-to-pdf" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your Word document (DOC or DOCX).", "Wait for the conversion to complete.", "Download your PDF file."]
const faqs = [
  { question: "Which Word formats are supported?", answer: "We support both DOC and DOCX formats." },
  { question: "Will my formatting be preserved?", answer: "Yes, all formatting, images, and fonts are preserved in the PDF." },
]

export default function WordToPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Word to PDF - PDFTools", "Convert Word documents to PDF format", "https://pdftools.com/word-to-pdf", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Convert Word to PDF", "Learn how to convert Word to PDF", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Word to PDF", url: "https://pdftools.com/word-to-pdf" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <WordToPDFClient />
    </>
  )
}
