"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { FileText } from "lucide-react"

export function WordToPDFClient() {
  return (
    <PDFToolPage
      title="Word to PDF"
      description="Make DOC and DOCX files easy to read by converting them to PDF."
      icon={<FileText className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#2563eb]"
      buttonText="Convert to PDF"
      acceptMultiple={true}
      acceptTypes=".doc,.docx"
      instructions={[
        "Upload your Word document (DOC or DOCX).",
        "Wait for the conversion to complete.",
        "Download your PDF file.",
      ]}
    />
  )
}
