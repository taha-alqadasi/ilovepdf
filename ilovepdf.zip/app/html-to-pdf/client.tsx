"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Globe } from "lucide-react"

export function HTMLToPDFClient() {
  return (
    <PDFToolPage
      title="HTML to PDF"
      description="Convert webpages in HTML to PDF. Copy and paste the URL of the page you want and convert it to PDF with a click."
      icon={<Globe className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#f59e0b]"
      buttonText="Convert to PDF"
      acceptMultiple={false}
      acceptTypes=".html,.htm"
      instructions={[
        "Paste the URL of the webpage you want to convert.",
        "Or upload an HTML file directly.",
        "Click 'Convert to PDF' to generate your document.",
        "Download your PDF file.",
      ]}
    />
  )
}
