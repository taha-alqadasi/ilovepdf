import type { Metadata } from "next"
import { HTMLToPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "HTML to PDF - Convert Webpage to PDF Online Free | PDFTools",
  description: "Convert HTML webpages to PDF online for free. Save any website as a PDF document. Just paste the URL and convert. No registration required.",
  keywords: ["html to pdf", "convert webpage to pdf", "website to pdf", "url to pdf", "save webpage as pdf", "html to pdf online"],
  openGraph: { title: "HTML to PDF - Convert Webpage to PDF Online Free", description: "Convert HTML webpages to PDF online for free.", url: "https://pdftools.com/html-to-pdf", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/html-to-pdf" },
  robots: { index: true, follow: true },
}

const instructions = ["Paste the webpage URL.", "Click convert.", "Download your PDF."]
const faqs = [{ question: "Can I convert any website?", answer: "Yes, you can convert most publicly accessible webpages to PDF." }]

export default function HTMLToPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("HTML to PDF - PDFTools", "Convert webpages to PDF", "https://pdftools.com/html-to-pdf", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Convert HTML to PDF", "Convert webpages to PDF", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "HTML to PDF", url: "https://pdftools.com/html-to-pdf" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <HTMLToPDFClient />
    </>
  )
}
