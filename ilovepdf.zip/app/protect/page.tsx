import type { Metadata } from "next"
import { ProtectPDFClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "Protect PDF - Add Password to PDF Online Free | PDFTools",
  description: "Protect PDF files with a password online for free. Encrypt your PDF documents to prevent unauthorized access. No registration required.",
  keywords: ["protect pdf", "password protect pdf", "encrypt pdf", "secure pdf", "lock pdf", "add password to pdf", "pdf security"],
  openGraph: { title: "Protect PDF - Add Password to PDF Online Free", description: "Protect PDF files with a password online for free.", url: "https://pdftools.com/protect", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/protect" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file.", "Set a strong password.", "Download your protected PDF."]
const faqs = [{ question: "How secure is the encryption?", answer: "We use AES-256 encryption, the same standard used by banks and governments." }]

export default function ProtectPDFPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("Protect PDF - PDFTools", "Add password protection to PDF files", "https://pdftools.com/protect", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Protect PDF with Password", "Add password to PDF files", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "Protect PDF", url: "https://pdftools.com/protect" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <ProtectPDFClient />
    </>
  )
}
