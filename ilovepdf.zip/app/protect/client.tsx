"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Lock } from "lucide-react"

export function ProtectPDFClient() {
  return (
    <PDFToolPage
      title="Protect PDF"
      description="Protect PDF files with a password. Encrypt PDF documents to prevent unauthorized access."
      icon={<Lock className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#16a34a]"
      buttonText="Protect PDF"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload the PDF file you want to protect.",
        "Enter a strong password.",
        "Click 'Protect PDF' to encrypt the file.",
        "Download your password-protected PDF.",
      ]}
    />
  )
}
