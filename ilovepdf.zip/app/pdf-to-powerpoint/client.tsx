"use client"

import { PDFToolPage } from "@/components/pdf-tool-page"
import { Presentation } from "lucide-react"

export function PDFToPPTClient() {
  return (
    <PDFToolPage
      title="PDF to PowerPoint"
      description="Turn your PDF files into easy to edit PPT and PPTX slideshows."
      icon={<Presentation className="h-8 w-8 text-white" />}
      iconBgColor="bg-[#ea580c]"
      buttonText="Convert to PowerPoint"
      acceptMultiple={false}
      acceptTypes=".pdf"
      instructions={[
        "Upload your PDF file.",
        "Wait for the conversion to complete.",
        "Download your PowerPoint presentation.",
      ]}
    />
  )
}
