import type { Metadata } from "next"
import { PDFToPPTClient } from "./client"
import { JsonLd, createWebApplicationSchema, createHowToSchema, createBreadcrumbSchema, createFAQSchema } from "@/components/json-ld"

export const metadata: Metadata = {
  title: "PDF to PowerPoint - Convert PDF to PPTX Online Free | PDFTools",
  description: "Convert PDF to PowerPoint presentations online for free. Transform PDF files into editable PPT and PPTX slideshows. No registration required.",
  keywords: ["pdf to powerpoint", "convert pdf to ppt", "pdf to pptx", "pdf to slides", "pdf to presentation", "pdf to powerpoint online"],
  openGraph: { title: "PDF to PowerPoint - Convert PDF to PPTX Online Free", description: "Convert PDF to PowerPoint presentations online for free.", url: "https://pdftools.com/pdf-to-powerpoint", siteName: "PDFTools", type: "website" },
  alternates: { canonical: "https://pdftools.com/pdf-to-powerpoint" },
  robots: { index: true, follow: true },
}

const instructions = ["Upload your PDF file.", "Wait for the conversion.", "Download your PowerPoint presentation."]
const faqs = [{ question: "Will slides be editable?", answer: "Yes, you can edit text, images, and formatting in the converted PowerPoint file." }]

export default function PDFToPPTPage() {
  return (
    <>
      <JsonLd data={createWebApplicationSchema("PDF to PowerPoint - PDFTools", "Convert PDF to PowerPoint presentations", "https://pdftools.com/pdf-to-powerpoint", "UtilitiesApplication")} />
      <JsonLd data={createHowToSchema("How to Convert PDF to PowerPoint", "Convert PDF to editable presentations", instructions)} />
      <JsonLd data={createBreadcrumbSchema([{ name: "Home", url: "https://pdftools.com" }, { name: "PDF to PowerPoint", url: "https://pdftools.com/pdf-to-powerpoint" }])} />
      <JsonLd data={createFAQSchema(faqs)} />
      <PDFToPPTClient />
    </>
  )
}
