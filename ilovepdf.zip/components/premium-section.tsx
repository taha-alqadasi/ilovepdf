import { Check, Crown } from "lucide-react"
import { Button } from "@/components/ui/button"

const benefits = [
  "Get full access to iLovePDF and work offline with Desktop",
  "Edit PDFs, get advanced OCR for scanned documents and request secure e-Signatures",
  "Connect tools and create custom workflows",
]

export function PremiumSection() {
  return (
    <section className="bg-[#FFF8E1] px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-[1400px]">
        <div className="flex flex-col items-center gap-12 lg:flex-row lg:items-start lg:justify-between">
          <div className="max-w-xl lg:pt-8">
            <h2 className="mb-8 text-3xl font-bold text-[#1D1D1F] sm:text-4xl">
              Get more with Premium
            </h2>
            
            <ul className="mb-8 space-y-4">
              {benefits.map((benefit) => (
                <li key={benefit} className="flex items-start gap-3">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#4CAF50]/10">
                    <Check className="h-4 w-4 text-[#4CAF50]" />
                  </div>
                  <span className="text-[#1D1D1F]">{benefit}</span>
                </li>
              ))}
            </ul>
            
            <Button className="rounded-lg bg-[#FFC107] px-6 py-3 text-base font-medium text-[#1D1D1F] hover:bg-[#FFB300] gap-2">
              <Crown className="h-5 w-5" />
              Get Premium
            </Button>
          </div>
          
          <div className="relative w-full max-w-lg">
            <div className="absolute -right-4 -top-4 h-32 w-32 rounded-full border-4 border-[#FFC107] opacity-50" />
            <div className="absolute -left-8 top-1/2 h-24 w-24 rounded-full bg-[#E5322D] opacity-20" />
            
            <div className="relative rounded-lg bg-white p-6 shadow-xl">
              <div className="mb-4 h-1 w-12 bg-[#E5322D]" />
              <h3 className="mb-2 text-xl font-bold text-[#1D1D1F]">Interior Design Project<br />Brief Approval</h3>
              
              <div className="mt-6 grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="h-2 w-full bg-gray-100 rounded" />
                  <div className="h-2 w-4/5 bg-gray-100 rounded" />
                  <div className="h-2 w-3/4 bg-gray-100 rounded" />
                  <div className="h-2 w-full bg-gray-100 rounded" />
                </div>
                <div className="rounded-lg bg-gray-100 h-24" />
              </div>
              
              <div className="mt-6 flex items-end justify-between">
                <div className="text-3xl italic text-[#1D1D1F] font-serif">Signature</div>
                <div className="rounded bg-[#E3F2FD] px-3 py-2 text-2xl font-bold text-[#2196F3]">Aa</div>
              </div>
            </div>
            
            <div className="absolute -bottom-6 left-8 flex items-center gap-2 rounded-full bg-[#FFC107] px-3 py-2 shadow-lg">
              <Crown className="h-5 w-5 text-white" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
