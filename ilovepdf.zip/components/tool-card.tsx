import Link from "next/link"
import type { LucideIcon } from "lucide-react"

interface ToolCardProps {
  title: string
  description: string
  href: string
  icon: LucideIcon
  iconBg: string
  iconColor: string
  badge?: string
}

export function ToolCard({ title, description, href, icon: Icon, iconBg, iconColor, badge }: ToolCardProps) {
  return (
    <Link
      href={href}
      className="group relative flex flex-col rounded-xl border border-gray-100 bg-white p-5 transition-all hover:border-gray-200 hover:shadow-lg"
    >
      {badge && (
        <span className="absolute right-3 top-3 rounded-full bg-[#E5322D] px-2 py-0.5 text-xs font-medium text-white">
          {badge}
        </span>
      )}
      <div
        className={`mb-4 flex h-14 w-14 items-center justify-center rounded-xl ${iconBg}`}
      >
        <Icon className={`h-7 w-7 ${iconColor}`} />
      </div>
      <h3 className="mb-2 text-base font-semibold text-[#1D1D1F]">{title}</h3>
      <p className="text-sm leading-relaxed text-[#6B6B6B]">{description}</p>
    </Link>
  )
}
