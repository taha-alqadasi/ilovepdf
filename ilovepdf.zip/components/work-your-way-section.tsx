import { ArrowUpRight } from "lucide-react"

const features = [
  {
    title: "Work offline with Desktop",
    description: "Batch edit and manage documents locally, with no internet and no limits.",
    image: "desktop",
  },
  {
    title: "On-the-go with Mobile",
    description: "Your favorite tools, right in your pocket. Keep working on your projects anytime, anywhere.",
    image: "mobile",
  },
  {
    title: "Built for business",
    description: "Automate document management, onboard teams easily, and scale with flexible plans.",
    image: "business",
  },
]

function DesktopIllustration() {
  return (
    <div className="relative h-48 w-full overflow-hidden rounded-t-lg bg-[#FEE9E5]">
      <div className="absolute left-1/2 top-8 -translate-x-1/2 w-[85%] bg-white rounded-t-lg shadow-lg overflow-hidden">
        <div className="flex items-center gap-1.5 bg-gray-100 px-3 py-2">
          <div className="h-2.5 w-2.5 rounded-full bg-[#FF5F57]" />
          <div className="h-2.5 w-2.5 rounded-full bg-[#FFBD2E]" />
          <div className="h-2.5 w-2.5 rounded-full bg-[#28CA41]" />
        </div>
        <div className="flex">
          <div className="w-1/4 border-r border-gray-100 p-3">
            <div className="flex items-center gap-2 text-xs text-gray-400 mb-3">
              <span>🏠</span><span>+</span>
            </div>
            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-2 text-gray-400"><span>⏱</span> Recent</div>
              <div className="flex items-center gap-2 text-[#E5322D]"><span>🔧</span> Tools</div>
              <div className="flex items-center gap-2 text-gray-400"><span>📜</span> History</div>
              <div className="flex items-center gap-2 text-gray-400"><span>⚙</span> Settings</div>
            </div>
          </div>
          <div className="flex-1 p-4">
            <div className="text-sm font-medium text-gray-700">Exclusivity agre<span className="text-[#E5322D]">ement</span></div>
            <div className="mt-2 space-y-1">
              <div className="h-2 w-full bg-gray-100 rounded" />
              <div className="h-2 w-4/5 bg-gray-100 rounded" />
              <div className="h-2 w-3/4 bg-gray-100 rounded" />
            </div>
            <div className="mt-4 flex justify-end">
              <div className="text-[#00BCD4] text-lg">✓</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function MobileIllustration() {
  return (
    <div className="relative h-48 w-full overflow-hidden rounded-t-lg bg-[#E8F5F5]">
      <div className="absolute left-1/2 top-6 -translate-x-1/2 w-32 bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200">
        <div className="flex items-center justify-between px-3 py-1 text-[8px] text-gray-500">
          <span>9:41</span>
          <div className="flex items-center gap-1">
            <span>📶</span><span>🔋</span>
          </div>
        </div>
        <div className="px-2 pb-2">
          <div className="mb-2 rounded overflow-hidden">
            <div className="bg-[#2196F3] h-8 flex items-center justify-center">
              <div className="bg-white/30 px-2 py-0.5 rounded text-[6px] text-white">Modern</div>
            </div>
            <div className="bg-gray-200 h-12" />
          </div>
          <div className="flex justify-end gap-1">
            <div className="w-4 h-4 rounded bg-gray-100 flex items-center justify-center text-[6px]">A</div>
          </div>
        </div>
      </div>
    </div>
  )
}

function BusinessIllustration() {
  return (
    <div className="relative h-48 w-full overflow-hidden rounded-t-lg bg-[#FEE9E5]">
      <div className="absolute left-4 top-6">
        <div className="flex items-center -space-x-2">
          <div className="h-8 w-8 rounded-full bg-[#00BCD4] border-2 border-white" />
          <div className="h-8 w-8 rounded-full bg-[#FFC107] border-2 border-white" />
          <div className="h-8 w-8 rounded-full bg-[#E5322D] border-2 border-white flex items-center justify-center text-white text-xs">+</div>
        </div>
      </div>
      <div className="absolute right-4 top-12 w-40 bg-white rounded-lg shadow-lg p-3">
        <div className="text-[#E5322D] text-xs font-medium mb-1">INVOICE</div>
        <div className="h-12 flex items-center justify-center">
          <div className="text-2xl text-[#1D1D1F] font-script italic">Signature</div>
        </div>
      </div>
      <div className="absolute right-2 top-24 w-32 bg-[#2D3748] rounded-lg p-2 text-[6px] font-mono text-green-400">
        <div className="text-gray-400">/*API*/</div>
        <div>{"{"}</div>
        <div className="pl-2">{`"id": "db601c95-045"`}</div>
        <div className="pl-2">{`"name": "rename-fil"`}</div>
        <div>{"}"}</div>
      </div>
    </div>
  )
}

export function WorkYourWaySection() {
  return (
    <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-[1400px]">
        <h2 className="mb-12 text-center text-3xl font-bold text-[#1D1D1F] sm:text-4xl">
          Work your way
        </h2>
        
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {features.map((feature, index) => (
            <div key={feature.title} className="group cursor-pointer">
              {index === 0 && <DesktopIllustration />}
              {index === 1 && <MobileIllustration />}
              {index === 2 && <BusinessIllustration />}
              <div className="p-6">
                <h3 className="mb-2 text-lg font-semibold text-[#1D1D1F]">{feature.title}</h3>
                <p className="mb-4 text-sm text-[#6B6B6B]">{feature.description}</p>
                <ArrowUpRight className="h-5 w-5 text-[#6B6B6B] transition-colors group-hover:text-[#E5322D]" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
