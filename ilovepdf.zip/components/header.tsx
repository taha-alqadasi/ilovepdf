"use client"

import Link from "next/link"
import { ChevronDown, Menu, X, LayoutGrid } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full bg-white border-b border-gray-100">
      <div className="mx-auto flex h-16 max-w-[1400px] items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-0.5">
            <span className="text-2xl font-black text-[#1D1D1F]">I</span>
            <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" fill="#E5322D"/>
            </svg>
            <span className="text-2xl font-black text-[#E5322D]">PDF</span>
          </Link>

          <nav className="hidden items-center gap-1 lg:flex">
            <Link href="/merge" className="px-4 py-2 text-sm font-medium text-[#1D1D1F] hover:text-[#E5322D] transition-colors">
              MERGE PDF
            </Link>
            <Link href="/split" className="px-4 py-2 text-sm font-medium text-[#1D1D1F] hover:text-[#E5322D] transition-colors">
              SPLIT PDF
            </Link>
            <Link href="/compress" className="px-4 py-2 text-sm font-medium text-[#1D1D1F] hover:text-[#E5322D] transition-colors">
              COMPRESS PDF
            </Link>
            <button className="flex items-center gap-1 px-4 py-2 text-sm font-medium text-[#1D1D1F] hover:text-[#E5322D] transition-colors">
              CONVERT PDF
              <ChevronDown className="h-4 w-4" />
            </button>
            <button className="flex items-center gap-1 px-4 py-2 text-sm font-medium text-[#1D1D1F] hover:text-[#E5322D] transition-colors">
              ALL PDF TOOLS
              <ChevronDown className="h-4 w-4" />
            </button>
          </nav>
        </div>

        <div className="hidden items-center gap-3 lg:flex">
          <Link href="/login" className="px-4 py-2 text-sm font-medium text-[#1D1D1F] hover:text-[#E5322D] transition-colors">
            Login
          </Link>
          <Button className="rounded-full bg-[#E5322D] px-5 py-2 text-sm font-medium text-white hover:bg-[#c92a25]">
            Sign up
          </Button>
          <button className="p-2 text-[#1D1D1F] hover:text-[#E5322D]">
            <LayoutGrid className="h-5 w-5" />
          </button>
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {mobileMenuOpen && (
        <div className="border-t border-gray-100 bg-white px-4 py-4 lg:hidden">
          <nav className="flex flex-col gap-2">
            <Link href="/merge" className="px-3 py-2 text-sm font-medium text-[#1D1D1F] hover:bg-gray-50 rounded">
              MERGE PDF
            </Link>
            <Link href="/split" className="px-3 py-2 text-sm font-medium text-[#1D1D1F] hover:bg-gray-50 rounded">
              SPLIT PDF
            </Link>
            <Link href="/compress" className="px-3 py-2 text-sm font-medium text-[#1D1D1F] hover:bg-gray-50 rounded">
              COMPRESS PDF
            </Link>
            <Link href="#" className="px-3 py-2 text-sm font-medium text-[#1D1D1F] hover:bg-gray-50 rounded">
              CONVERT PDF
            </Link>
            <Link href="/#tools" className="px-3 py-2 text-sm font-medium text-[#1D1D1F] hover:bg-gray-50 rounded">
              ALL PDF TOOLS
            </Link>
            <div className="flex flex-col gap-2 pt-4 border-t border-gray-100 mt-2">
              <Link href="/login" className="px-3 py-2 text-sm font-medium text-[#1D1D1F] hover:bg-gray-50 rounded text-center">
                Login
              </Link>
              <Button className="rounded-full bg-[#E5322D] text-white hover:bg-[#c92a25]">
                Sign up
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
