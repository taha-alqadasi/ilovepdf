import { Shield, Lock, Award } from "lucide-react"

export function TrustSection() {
  return (
    <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-[1400px] text-center">
        <h2 className="mb-4 text-3xl font-bold text-[#1D1D1F] sm:text-4xl">
          The PDF software trusted by millions of users
        </h2>
        <p className="mx-auto mb-12 max-w-3xl text-[#6B6B6B]">
          iLovePDF is your number one web app for editing PDF with ease. Enjoy all the tools you need to work efficiently with your digital documents while keeping your data safe and secure.
        </p>
        
        <div className="flex flex-wrap items-center justify-center gap-12">
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-center gap-1">
              <Award className="h-8 w-8 text-[#1D1D1F]" />
              <span className="text-xl font-bold text-[#1D1D1F]">ISO</span>
              <span className="text-sm text-[#6B6B6B]">27001</span>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-center gap-2">
              <Lock className="h-6 w-6 text-[#1D1D1F]" />
              <div className="text-left">
                <div className="text-lg font-bold text-[#1D1D1F]">SECURE</div>
                <div className="text-xs text-[#6B6B6B]">SSL ENCRYPTION</div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-center gap-1">
              <Shield className="h-6 w-6 text-[#1D1D1F]" />
              <div className="text-left">
                <div className="text-lg font-bold text-[#1D1D1F]">PDF</div>
                <div className="text-xs text-[#6B6B6B]">association</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
