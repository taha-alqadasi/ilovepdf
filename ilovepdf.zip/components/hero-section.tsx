"use client"

import { useState } from "react"

const categories = [
  "All",
  "Workflows",
  "Organize PDF",
  "Optimize PDF",
  "Convert PDF",
  "Edit PDF",
  "PDF Security",
  "PDF Intelligence",
]

export function HeroSection() {
  const [activeCategory, setActiveCategory] = useState("All")

  return (
    <section className="bg-white px-4 pt-12 pb-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-[1400px] text-center">
        <h1 className="mb-4 text-balance text-3xl font-bold tracking-tight text-[#1D1D1F] sm:text-4xl lg:text-[42px] lg:leading-tight">
          Every tool you need to work with PDFs in one place
        </h1>
        
        <p className="mx-auto mb-8 max-w-3xl text-pretty text-base text-[#6B6B6B] sm:text-lg">
          Every tool you need to use PDFs, at your fingertips. All are 100% FREE and easy to use! Merge, split, compress, convert, rotate, unlock and watermark PDFs with just a few clicks.
        </p>
        
        <div className="flex flex-wrap items-center justify-center gap-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`rounded-full px-5 py-2 text-sm font-medium transition-all ${
                activeCategory === category
                  ? "bg-[#1D1D1F] text-white"
                  : "bg-white text-[#1D1D1F] border border-gray-200 hover:border-gray-300"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}
