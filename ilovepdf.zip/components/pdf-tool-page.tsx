"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Upload, FileText, X, Plus, ArrowRight } from "lucide-react"
import { useState, useCallback, type ReactNode } from "react"

interface UploadedFile {
  id: string
  name: string
  size: number
}

interface PDFToolPageProps {
  title: string
  description: string
  icon: ReactNode
  iconBgColor: string
  buttonText: string
  acceptMultiple?: boolean
  acceptTypes?: string
  instructions: string[]
}

export function PDFToolPage({
  title,
  description,
  icon,
  iconBgColor,
  buttonText,
  acceptMultiple = true,
  acceptTypes = ".pdf",
  instructions,
}: PDFToolPageProps) {
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [isDragging, setIsDragging] = useState(false)

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    
    const droppedFiles = Array.from(e.dataTransfer.files)
    
    const newFiles: UploadedFile[] = droppedFiles.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
    }))
    
    if (acceptMultiple) {
      setFiles(prev => [...prev, ...newFiles])
    } else {
      setFiles(newFiles.slice(0, 1))
    }
  }, [acceptMultiple])

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return
    
    const selectedFiles = Array.from(e.target.files)
    
    const newFiles: UploadedFile[] = selectedFiles.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
    }))
    
    if (acceptMultiple) {
      setFiles(prev => [...prev, ...newFiles])
    } else {
      setFiles(newFiles.slice(0, 1))
    }
    e.target.value = ""
  }, [acceptMultiple])

  const removeFile = useCallback((id: string) => {
    setFiles(prev => prev.filter(file => file.id !== id))
  }, [])

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 bg-muted/30 px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl">
          <div className="mb-8 text-center">
            <div className={`mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl ${iconBgColor}`}>
              {icon}
            </div>
            <h1 className="mb-2 text-3xl font-bold text-foreground sm:text-4xl">
              {title}
            </h1>
            <p className="text-muted-foreground">
              {description}
            </p>
          </div>

          <div
            className={`relative rounded-xl border-2 border-dashed bg-card p-8 text-center transition-colors ${
              isDragging
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary/50"
            }`}
            onDragOver={(e) => {
              e.preventDefault()
              setIsDragging(true)
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
          >
            <input
              type="file"
              accept={acceptTypes}
              multiple={acceptMultiple}
              onChange={handleFileSelect}
              className="absolute inset-0 cursor-pointer opacity-0"
            />
            <Upload className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
            <h3 className="mb-2 text-lg font-semibold text-foreground">
              Drop files here
            </h3>
            <p className="mb-4 text-sm text-muted-foreground">
              or click to browse your files
            </p>
            <Button variant="outline" size="sm" className="pointer-events-none">
              <Plus className="mr-2 h-4 w-4" />
              Select files
            </Button>
          </div>

          {files.length > 0 && (
            <div className="mt-6">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-semibold text-foreground">
                  {files.length} file{files.length !== 1 ? "s" : ""} selected
                </h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFiles([])}
                  className="text-muted-foreground"
                >
                  Clear all
                </Button>
              </div>
              
              <div className="space-y-2">
                {files.map((file, index) => (
                  <div
                    key={file.id}
                    className="flex items-center gap-4 rounded-lg border border-border bg-card p-4"
                  >
                    <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${iconBgColor}/10`}>
                      <FileText className={`h-5 w-5 ${iconBgColor.replace('bg-', 'text-').replace('-500', '-500')}`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium text-foreground">
                        {index + 1}. {file.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {formatFileSize(file.size)}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeFile(file.id)}
                      className="h-8 w-8 text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex justify-center">
                <Button size="lg" className="gap-2">
                  {buttonText}
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          <div className="mt-12 rounded-xl bg-card p-6">
            <h2 className="mb-4 text-lg font-semibold text-foreground">
              How to use this tool
            </h2>
            <ol className="space-y-3 text-sm text-muted-foreground">
              {instructions.map((instruction, index) => (
                <li key={index} className="flex gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-medium text-primary-foreground">
                    {index + 1}
                  </span>
                  <span>{instruction}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
